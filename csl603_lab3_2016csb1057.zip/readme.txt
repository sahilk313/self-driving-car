>>python ann.py

to compile the program.
The variables like num epochs, learning rate and batch size can be modified on the first lines of the program ann.py

The graph plotted by default is training error vs epochs.
The default values of epoch has already benn fed.

NOTE: python2 is required to run the program